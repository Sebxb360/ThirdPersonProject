﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy : MonoBehaviour
{

    public float killTime = 4;

    // Use this for initialization
    void Start()
    {
        StartCoroutine("Kill");
    }

    IEnumerator Kill()
    {
        yield return new WaitForSeconds(killTime);

        Destroy(this.gameObject);
    }

}	
