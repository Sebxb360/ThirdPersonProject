﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : MonoBehaviour
{
    public List<Rigidbody> wallPieces;

    public void DestroyWall(Vector3 damage)
    {
        GetComponent<Collider>().enabled = false;
        foreach (Rigidbody piece in wallPieces)
        {
            piece.transform.parent = null;
            piece.gameObject.SetActive(true);
            piece.isKinematic = false;
            piece.AddForce((damage.normalized + Random.Range(-0.5f, 0.5f) * Vector3.Cross(damage.normalized, Vector3.up).normalized) * 10, ForceMode.Impulse);
        }
        gameObject.SetActive(false);
    }
}