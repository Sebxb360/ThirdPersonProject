﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class RaycastWeaponData : WeaponData
{
    public GameObject trail;
    public GameObject hitParticle;

    public float range;
}

public class RaycasrWeapon : Weapon
{
    public RaycastWeaponData raycastData;

    protected override void Start()
    {
        data = raycastData;
        base.Start();
    }

    protected override void LaunchProjectile()
    {
        base.LaunchProjectile();
        RaycastHit hit;
        GameObject bulletTrail = Instantiate(raycastData.trail, raycastData.muzzle.position, Quaternion.LookRotation(raycastData.muzzle.forward));

        if (Physics.Raycast(raycastData.muzzle.position,raycastData.muzzle.transform.forward, out hit, raycastData.range, ~raycastData.myPlayerLayer))
        {
            bulletTrail.transform.localScale = new Vector3(1, 1, (hit.point - raycastData.muzzle.position).magnitude);
            Debug.DrawRay(raycastData.muzzle.position, raycastData.muzzle.forward * hit.distance, Color.red);
            ///Debug.Log("Did Hit!!");
            Instantiate(raycastData.hitParticle, hit.point, Quaternion.identity);

            if (hit.collider.gameObject.GetComponent<HitBoxScript>())
            {
                hit.collider.gameObject.GetComponent<HitBoxScript>().onHit.Invoke(data.damage * raycastData.muzzle.forward);
            }
        }
        else
        {
            bulletTrail.transform.localScale = new Vector3(1, 1, raycastData.range);
        }
    }

}
