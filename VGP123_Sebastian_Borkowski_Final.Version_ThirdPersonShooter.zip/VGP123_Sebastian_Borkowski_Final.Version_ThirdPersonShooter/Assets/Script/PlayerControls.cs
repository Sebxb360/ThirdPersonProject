﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerControls : MonoBehaviour {

    public float forwardSpeed = 10;
    public float sidewaySpeed = 5;
    public float rotationSpeed = 1;
    public Animator anim;
    public Weapon weapon;
    public List<Weapon> myWeapons = new List<Weapon>();
    public GameObject W;
    public List<GameObject> myW = new List<GameObject>();

    public float maxHealth = 100;
    private float currentHealth;

    private static PlayerControls Instance;
    private Rigidbody rb;
    public int index;
    public int Windex;

    private void Awake()
    {
        if (Instance)
        {
            Destroy(Instance.gameObject);
        }
        Instance = this;
    }

    // Use this for initialization
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        Move();
        Rotate();
        Shoot();
        SwitchWeapons();

    }

    public static PlayerControls GetInstance()
    {
        return Instance;
    }
    private void Move()
    {
        Vector3 forward = Input.GetAxis("Vertical") * forwardSpeed * transform.forward;
        Vector3 sideways = Input.GetAxis("Horizontal") * sidewaySpeed * transform.right;
        //transform.position += (forward  + sideways) * Time.deltaTime;
        Vector3 moveDir = forward + sideways;
        anim.SetFloat("DirectionX", Vector3.Dot(moveDir.normalized, transform.right));
        anim.SetFloat("DirectionY", Vector3.Dot(moveDir.normalized, transform.forward));
        rb.AddForce(forward + sideways);

    }

    void Rotate()
    {
        Vector3 lookAtPoint = transform.position + transform.forward;
        lookAtPoint += Input.GetAxis("Mouse X") * rotationSpeed * transform.right * Time.deltaTime;
        transform.LookAt(lookAtPoint);
    }

    void Shoot()
    {
        if (Input.GetButton("Fire1"))
        {
            weapon.Fire();
        }

        else
        {
            weapon.StopFiring();
        }
    }

    void SwitchWeapons()
    {
        if (Input.GetButtonDown("Fire2") && !weapon.reloading)
        {
            weapon.gameObject.SetActive(false);
            index = (index + 1) % myWeapons.Count;
            weapon = myWeapons[index];
            weapon.gameObject.SetActive(true);

            W.gameObject.SetActive(false);
            Windex = (Windex + 1) % myW.Count;
            W = myW[Windex];
            W.gameObject.SetActive(true);

        }
    }
    public void Damage(Vector3 damage)
    {
        currentHealth -= damage.magnitude;
        if (currentHealth <= 0)
        {
            SceneManager.LoadScene(0);
        }
    }
    
}

